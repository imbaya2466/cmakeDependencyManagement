/* Obsolete; consider using unistd.h instead.  */

/* Get getpass declaration, if available.  */
#include <unistd.h>
